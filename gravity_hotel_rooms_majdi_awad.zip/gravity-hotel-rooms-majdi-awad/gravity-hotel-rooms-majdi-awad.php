<?php

/**

Plugin Name: Gravity Hotel Rooms - Majdi Awad 
Plugin URI: https://googlit.tech/word/wp/ 
Description: This plugin will support the WordPress administrator at Gravity Hotel to create pages and posts to present the hotel rooms. This is a demo version to be added to my resume.
Version: 1.0 
Author: Majdi Awad 
Author URI: http://googlit.tech/ 

This plugin will support the WordPress administrator at Gravity Hotel to create pages and posts to present the hotel rooms. This is a demo version to be added to my resume. 

Generate by Plugin Maker ~ http://codecanyon.net/item/wordpress-plugin-maker-freelancer-version/13581496

**/

# Exit if accessed directly
if (!defined("ABSPATH"))
{
	exit;
}

# Constant

/**
 * Exec Mode
 **/
define("GHR_EXEC",true);

/**
 * Plugin Base File
 **/
define("GHR_PATH",dirname(__FILE__));

/**
 * Plugin Base Directory
 **/
define("GHR_DIR",basename(GHR_PATH));

/**
 * Plugin Base URL
 **/
define("GHR_URL",plugins_url("/",__FILE__));

/**
 * Plugin Version
 **/
define("GHR_VERSION","1.0"); 

/**
 * Debug Mode
 **/
define("GHR_DEBUG",false);  //change false for distribution



/**
 * Base Class Plugin
 * @author Majdi Awad
 *
 * @access public
 * @version 1.0
 * @package Gravity Hotel Rooms - Majdi Awad
 *
 **/

class GravityHotelRoomsMajdiAwad
{

	/**
	 * Instance of a class
	 * @access public
	 * @return void
	 **/

	function __construct()
	{
		add_action("plugins_loaded", array($this, "GHR_textdomain")); //load language/textdomain
		add_action("wp_enqueue_scripts",array($this,"GHR_enqueue_scripts")); //add js
		add_action("wp_enqueue_scripts",array($this,"GHR_enqueue_styles")); //add css
		add_action("init", array($this, "GHR_post_type_room_init")); // register a room post type.
		add_filter("the_content", array($this, "GHR_post_type_room_the_content")); // modif page for room
		add_action("rest_prepare_room", array($this, "GHR_rest_prepare_room"),10,3); 
		add_action("after_setup_theme", array($this, "GHR_image_size")); // register image size.
		add_filter("image_size_names_choose", array($this, "GHR_image_sizes_choose")); // image size choose.
		add_action("init", array($this, "GHR_register_taxonomy")); // register register_taxonomy.
		add_action("wp_head",array($this,"GHR_dinamic_js"),1); //load dinamic js
		if(is_admin()){
			add_action("add_meta_boxes",array($this,"GHR_metabox_ghr")); //add metabox GHR
			add_action("save_post",array($this,"GHR_metabox_ghr_save")); //save metabox GHR data
			add_action("admin_enqueue_scripts",array($this,"GHR_admin_enqueue_scripts")); //add js for admin
			add_action("admin_enqueue_scripts",array($this,"GHR_admin_enqueue_styles")); //add css for admin
		}
	}


	/**
	 * Loads the plugin's translated strings
	 * @link http://codex.wordpress.org/Function_Reference/load_plugin_textdomain
	 * @access public
	 * @return void
	 **/
	public function GHR_textdomain()
	{
		load_plugin_textdomain("gravity-hotel-rooms-majdi-awad", false, GHR_DIR . "/languages");
	}


	/**
	 * Add Metabox (ghr)
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/add_meta_box
	 * @param mixed $hooks
	 * @access public
	 * @return void
	 **/
	public function GHR_metabox_ghr($hook)
	{
		$allowed_hook = array("room","post","page"); //limit meta box to certain page
		if(in_array($hook, $allowed_hook))
		{
			add_meta_box("GHR_metabox_ghr", __("GHR", "gravity-hotel-rooms-majdi-awad"),array($this,"GHR_metabox_ghr_callback"),$hook,"normal","high");
		}
	}


	/**
	 * Create metabox markup (ghr)
	 * 
	 * @param mixed $post
	 * @access public
	 * @return void
	 **/
	public function GHR_metabox_ghr_callback($post)
	{
		// Add a nonce field so we can check for it later.
		wp_nonce_field("GHR_metabox_ghr_save","GHR_metabox_ghr_nonce");
		if(file_exists(GHR_PATH . "/includes/metabox.ghr.inc.php")){
			require_once(GHR_PATH . "/includes/metabox.ghr.inc.php");
			$ghr_metabox = new Ghr_Metabox();
			$ghr_metabox->Markup($post);
		}
	}


	/**
	 *
	 * Save the meta when the post is saved.
	 * GravityHotelRoomsMajdiAwad::GHR_metabox_ghr_save()
	 * @param int $post_id The ID of the post being saved.
	 *
	**/
	public function GHR_metabox_ghr_save($post_id)
	{

		/*
		 * We need to verify this came from the our screen and with proper authorization,
		 * because save_post can be triggered at other times.
		 */

		// Check if our nonce is set.
		if (!isset($_POST["GHR_metabox_ghr_nonce"]))
			return $post_id;
		$nonce = $_POST["GHR_metabox_ghr_nonce"];

		// Verify that the nonce is valid.
		if(!wp_verify_nonce($nonce, "GHR_metabox_ghr_save"))
			return $post_id;

		// If this is an autosave, our form has not been submitted,
		// so we don't want to do anything.
		if (defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
			return $post_id;

		// Check the user's permissions.
		if ("page" == $_POST["post_type"])
		{
			if (!current_user_can("edit_page", $post_id))
				return $post_id;
		} else
		{
			if (!current_user_can("edit_post", $post_id))
				return $post_id;
		}

		/* OK, its safe for us to save the data now. */

		// Sanitize the user input.
		//select
		$room_type = sanitize_text_field($_POST["GHR_postmeta_room_type"] );

		// Update the meta field.
		update_post_meta($post_id, "_GHR_postmeta_room_type", $room_type);

		// Sanitize the user input.
		//select
		$bed_type = sanitize_text_field($_POST["GHR_postmeta_bed_type"] );

		// Update the meta field.
		update_post_meta($post_id, "_GHR_postmeta_bed_type", $bed_type);

		// Sanitize the user input.
		//select
		$sea_view = sanitize_text_field($_POST["GHR_postmeta_sea_view"] );

		// Update the meta field.
		update_post_meta($post_id, "_GHR_postmeta_sea_view", $sea_view);

		// Sanitize the user input.
		//select
		$balcony = sanitize_text_field($_POST["GHR_postmeta_balcony"] );

		// Update the meta field.
		update_post_meta($post_id, "_GHR_postmeta_balcony", $balcony);

		// Sanitize the user input.
		//select
		$pool_view = sanitize_text_field($_POST["GHR_postmeta_pool_view"] );

		// Update the meta field.
		update_post_meta($post_id, "_GHR_postmeta_pool_view", $pool_view);

		// Sanitize the user input.
		//select
		$bath = sanitize_text_field($_POST["GHR_postmeta_bath"] );

		// Update the meta field.
		update_post_meta($post_id, "_GHR_postmeta_bath", $bath);

		// Sanitize the user input.
		//select
		$air_conditioning = sanitize_text_field($_POST["GHR_postmeta_air_conditioning"] );

		// Update the meta field.
		update_post_meta($post_id, "_GHR_postmeta_air_conditioning", $air_conditioning);

		// Sanitize the user input.
		//select
		$ensuite_bathroom = sanitize_text_field($_POST["GHR_postmeta_ensuite_bathroom"] );

		// Update the meta field.
		update_post_meta($post_id, "_GHR_postmeta_ensuite_bathroom", $ensuite_bathroom);

		// Sanitize the user input.
		//select
		$free_wifi = sanitize_text_field($_POST["GHR_postmeta_free_wifi"] );

		// Update the meta field.
		update_post_meta($post_id, "_GHR_postmeta_free_wifi", $free_wifi);

		// Sanitize the user input.
		//select
		$flat_screen_tv = sanitize_text_field($_POST["GHR_postmeta_flat_screen_tv"] );

		// Update the meta field.
		update_post_meta($post_id, "_GHR_postmeta_flat_screen_tv", $flat_screen_tv);

	}




	/**
	 * Insert javascripts for back-end
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/wp_enqueue_script
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function GHR_admin_enqueue_scripts($hooks)
	{
		if (function_exists("get_current_screen")) {
			$screen = get_current_screen();
		}else{
			$screen = $hooks;
		}
	
		// limit page only room, post, page
		if(( in_array($hooks,array("room","post","page")))||( in_array($screen->post_type,array("room","post","page")))){
			wp_enqueue_script("GHR_admin_metabox", GHR_URL . "assets/js/GHR_admin_metabox.js", array("jquery","thickbox"),"1.0",true );
		}
	}


	/**
	 * Insert javascripts for front-end
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/wp_enqueue_script
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function GHR_enqueue_scripts($hooks)
	{
			wp_enqueue_script("GHR_main", GHR_URL . "assets/js/GHR_main.js", array("jquery"),"1.0",true );
	}


	/**
	 * Insert CSS for back-end
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/wp_register_style
	 * @link http://codex.wordpress.org/Function_Reference/wp_enqueue_style
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function GHR_admin_enqueue_styles($hooks)
	{
		if (function_exists("get_current_screen")) {
			$screen = get_current_screen();
		}else{
			$screen = $hooks;
		}
		// register css
		wp_register_style("GHR_metabox", GHR_URL . "assets/css/GHR_admin_metabox.css",array(),"1.0" );
	
		// limit page
		if(( in_array($hooks,array("room","post","page")))||( in_array($screen->post_type,array("room","post","page")))){
			wp_enqueue_style("GHR_metabox");
		}
	}


	/**
	 * Insert CSS for front-end
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/wp_register_style
	 * @link http://codex.wordpress.org/Function_Reference/wp_enqueue_style
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function GHR_enqueue_styles($hooks)
	{
		// register css
		wp_register_style("GHR_main", GHR_URL . "assets/css/GHR_main.css",array(),"1.0" );
			wp_enqueue_style("GHR_main");
	}


	/**
	 * Register custom post types (room)
	 *
	 * @link http://codex.wordpress.org/Function_Reference/register_post_type
	 * @access public
	 * @return void
	 **/

	public function GHR_post_type_room_init()
	{

		$labels = array(
			'name' => _x('Rooms', 'post type general name', 'gravity-hotel-rooms-majdi-awad'),
			'singular_name' => _x('Room', 'post type singular name', 'gravity-hotel-rooms-majdi-awad'),
			'menu_name' => _x('Rooms', 'admin menu', 'gravity-hotel-rooms-majdi-awad'),
			'name_admin_bar' => _x('Rooms', 'add new on admin bar', 'gravity-hotel-rooms-majdi-awad'),
			'add_new' => _x('Add New Room', 'book', 'gravity-hotel-rooms-majdi-awad'),
			'add_new_item' => __('Add New Room', 'gravity-hotel-rooms-majdi-awad'),
			'new_item' => __('New Room', 'gravity-hotel-rooms-majdi-awad'),
			'edit_item' => __('Edit Room', 'gravity-hotel-rooms-majdi-awad'),
			'view_item' => __('View Room', 'gravity-hotel-rooms-majdi-awad'),
			'all_items' => __('All Rooms', 'gravity-hotel-rooms-majdi-awad'),
			'search_items' => __('Search Rooms', 'gravity-hotel-rooms-majdi-awad'),
			'parent_item_colon' => __('Parent Room', 'gravity-hotel-rooms-majdi-awad'),
			'not_found' => __('No Rooms Found', 'gravity-hotel-rooms-majdi-awad'),
			'not_found_in_trash' => __('No Rooms Found in Trash', 'gravity-hotel-rooms-majdi-awad'));

			$supports = array('title','thumbnail');

			$args = array(
				'labels' => $labels,
				'description' => __('Demo Version', 'gravity-hotel-rooms-majdi-awad'),
				'public' => true,
				'menu_icon' => 'dashicons-editor-table',
				'publicly_queryable' => true,
				'show_ui' => true,
				'show_in_menu' => true,
				'query_var' => true,
				'rewrite' => array('slug' => 'room'),
				'capability_type' => 'post',
				'has_archive' => true,
				'hierarchical' => true,
				'menu_position' => null,
				'show_in_rest' => true,
				'rest_base' => 'room',
				'taxonomies' => array(), // array('category', 'post_tag','page-category'),
				'supports' => $supports);

			register_post_type('room', $args);

		// create single template
		add_filter("single_template", array($this, "GHR_post_type_room_single_template"));

	}


	/**
	 * Load Single Template (room)
	 *
	 * @access public
	 * @param mixed $single_template
	 * @return void
	 **/

	public function GHR_post_type_room_single_template($single_template)
	{

		global $post;
		if(file_exists(GHR_PATH . "/templates/single-room.php" ))
		{
			if ($post->post_type == "room")
			{
				$single_template = GHR_PATH . "/templates/single-room.php";
			}
		}
		return $single_template;
	}


	/**
	 * Retrieved data custom post-types (room)
	 *
	 * @access public
	 * @param mixed $content
	 * @return void
	 * @link https://codex.wordpress.org/Plugin_API/Filter_Reference/the_content
	 **/

	public function GHR_post_type_room_the_content($content)
	{

		$new_content = $content ;
		if(is_singular("room")){
			if(file_exists(GHR_PATH . "/includes/post_type.room.inc.php")){
				require_once(GHR_PATH . "/includes/post_type.room.inc.php");
				$room_content = new Room_TheContent();
				$new_content = $room_content->Markup($content);
				wp_reset_postdata();
			}
		}

		return $new_content ;

	}


	/**
	 * rest prepare
	 *
	 * @access public
	 * @param mixed $data
	 * @param mixed $term
	 * @param mixed $context
	 * @return void
	 * @link https://developer.wordpress.org/reference/hooks/rest_prepare_this-post_type/
	 **/

	public function GHR_rest_prepare_room($data,$term,$context)
	{
		$oldData = $data->data;
		$newData = $oldData;
		$newData["post_meta"] = get_post_meta($oldData["id"],"",true);
		$data->data = $newData;
		return $data;
	}


	/**
	 * Register a new image size.
	 * @link http://codex.wordpress.org/Function_Reference/add_image_size
	 * @access public
	 * @return void
	 **/
	public function GHR_image_size()
	{
	}


	/**
	 * Choose a image size.
	 * @access public
	 * @param mixed $sizes
	 * @return void
	 **/
	public function GHR_image_sizes_choose($sizes)
	{
		$custom_sizes = array(
		);
		return array_merge($sizes,$custom_sizes);
	}


	/**
	 * Register Taxonomies
	 * @https://codex.wordpress.org/Taxonomies
	 * @access public
	 * @return void
	 **/
	public function GHR_register_taxonomy()
	{
	}


	/**
	 * Insert Dinamic JS
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function GHR_dinamic_js($hooks)
	{
		_e("<script type=\"text/javascript\">");
		_e("</script>");
	}
}


new GravityHotelRoomsMajdiAwad();
