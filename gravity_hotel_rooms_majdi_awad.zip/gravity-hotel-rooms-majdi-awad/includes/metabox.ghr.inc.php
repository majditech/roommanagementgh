<?php

/**
 * Metabox (GHR)
 *
**/

# Exit if accessed directly
if(!defined("GHR_EXEC")){
	die();
}


 /**
  * Dispaly back-end metabox ghr
  * 
  * @package Gravity Hotel Rooms - Majdi Awad
  * @author Majdi Awad
  * @version 1.0
  * @access public
  * 
  * Generate by Plugin Maker ~ http://codecanyon.net/item/wordpress-plugin-maker-freelancer-version/13581496
  */

class Ghr_Metabox{


	/**
	 * Option Plugin
	 * @access private
	 **/
	private $options;

	/**
	 * Instance of a class
	 * 
	 * @access public
	 * @return void
	 **/

	function __construct(){
		$this->options = get_option("gravity_hotel_rooms_majdi_awad_plugins"); // get current option

	}

	/**
	 * Create Metabox Markup
	 * 
	 * @param mixed $post
	 * @access public
	 * @return void
	 **/

	public function Markup($post){

		// TODO: EDIT HTML METABOX GHR
		if(GHR_DEBUG==true){
			$file_info = null; 
			$file_info .= "<p>You can edit the file below to fix the metabox</p>" ; 
			$file_info .= "<div>" ; 
			$file_info .= "<pre style=\"color:rgba(255,0,0,1);padding:3px;margin:0px;background:rgba(255,0,0,0.1);border:1px solid rgba(255,0,0,0.5);font-size:11px;font-family:monospace;white-space:pre-wrap;\">%s:%s</pre>" ; 
			$file_info .= "</div>" ; 
			printf($file_info,__FILE__,__LINE__);
		}
		/**
		* You can make HTML tag for Metabox GHR here
		**/

		echo "<h4>Gravity Hotel Rooms - Demo</h4>";
		printf("<table class=\"form-table\">");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_GHR_postmeta_room_type= get_post_meta($post->ID, "_GHR_postmeta_room_type", true);

		/** Display the form room_type, using the current value. **/
		$input_options = array();
		$input_options[] = array("value"=>"single","label"=>__("Single","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"double","label"=>__("Double","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"triple","label"=>__("Triple","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"quad","label"=>__("Quad","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"queen","label"=>__("Queen","gravity-hotel-rooms-majdi-awad")) ;
		printf("<tr>");
		printf("<th scope=\"row\"><label class=\"GHR-control-label\" for=\"GHR_postmeta_room_type\">". __("Room Type", "gravity-hotel-rooms-majdi-awad"). "</label></th>");
		printf("<td>");
		printf("<select class=\"GHR GHR-form-control\" id=\"GHR_postmeta_room_type\" name=\"GHR_postmeta_room_type\" >") ;
		foreach ($input_options as $input_option)
		{
			$selected="";
			if($input_option["value"]== $current_GHR_postmeta_room_type){ $selected="selected=\"selected\"";}
			printf("<option value='".$input_option["value"]."' ".$selected.">".$input_option["label"]."</option>") ;
		}
		printf("</select>") ;
		printf("</td>") ;
		printf("</tr>");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_GHR_postmeta_bed_type= get_post_meta($post->ID, "_GHR_postmeta_bed_type", true);

		/** Display the form bed_type, using the current value. **/
		$input_options = array();
		$input_options[] = array("value"=>"standard_double","label"=>__("Standard Double","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"queen_bed","label"=>__("Queen Bed","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"olympic_queen","label"=>__("Olympic Queen","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"king_bed","label"=>__("King Bed","gravity-hotel-rooms-majdi-awad")) ;
		printf("<tr>");
		printf("<th scope=\"row\"><label class=\"GHR-control-label\" for=\"GHR_postmeta_bed_type\">". __("Bed Type", "gravity-hotel-rooms-majdi-awad"). "</label></th>");
		printf("<td>");
		printf("<select class=\"GHR GHR-form-control\" id=\"GHR_postmeta_bed_type\" name=\"GHR_postmeta_bed_type\" >") ;
		foreach ($input_options as $input_option)
		{
			$selected="";
			if($input_option["value"]== $current_GHR_postmeta_bed_type){ $selected="selected=\"selected\"";}
			printf("<option value='".$input_option["value"]."' ".$selected.">".$input_option["label"]."</option>") ;
		}
		printf("</select>") ;
		printf("</td>") ;
		printf("</tr>");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_GHR_postmeta_sea_view= get_post_meta($post->ID, "_GHR_postmeta_sea_view", true);

		/** Display the form sea_view, using the current value. **/
		$input_options = array();
		$input_options[] = array("value"=>"yes","label"=>__("Yes","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"no","label"=>__("No","gravity-hotel-rooms-majdi-awad")) ;
		printf("<tr>");
		printf("<th scope=\"row\"><label class=\"GHR-control-label\" for=\"GHR_postmeta_sea_view\">". __("Sea View", "gravity-hotel-rooms-majdi-awad"). "</label></th>");
		printf("<td>");
		printf("<select class=\"GHR GHR-form-control\" id=\"GHR_postmeta_sea_view\" name=\"GHR_postmeta_sea_view\" >") ;
		foreach ($input_options as $input_option)
		{
			$selected="";
			if($input_option["value"]== $current_GHR_postmeta_sea_view){ $selected="selected=\"selected\"";}
			printf("<option value='".$input_option["value"]."' ".$selected.">".$input_option["label"]."</option>") ;
		}
		printf("</select>") ;
		printf("</td>") ;
		printf("</tr>");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_GHR_postmeta_balcony= get_post_meta($post->ID, "_GHR_postmeta_balcony", true);

		/** Display the form balcony, using the current value. **/
		$input_options = array();
		$input_options[] = array("value"=>"yes","label"=>__("Yes","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"no","label"=>__("No","gravity-hotel-rooms-majdi-awad")) ;
		printf("<tr>");
		printf("<th scope=\"row\"><label class=\"GHR-control-label\" for=\"GHR_postmeta_balcony\">". __("Balcony", "gravity-hotel-rooms-majdi-awad"). "</label></th>");
		printf("<td>");
		printf("<select class=\"GHR GHR-form-control\" id=\"GHR_postmeta_balcony\" name=\"GHR_postmeta_balcony\" >") ;
		foreach ($input_options as $input_option)
		{
			$selected="";
			if($input_option["value"]== $current_GHR_postmeta_balcony){ $selected="selected=\"selected\"";}
			printf("<option value='".$input_option["value"]."' ".$selected.">".$input_option["label"]."</option>") ;
		}
		printf("</select>") ;
		printf("</td>") ;
		printf("</tr>");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_GHR_postmeta_pool_view= get_post_meta($post->ID, "_GHR_postmeta_pool_view", true);

		/** Display the form pool_view, using the current value. **/
		$input_options = array();
		$input_options[] = array("value"=>"yes","label"=>__("Yes","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"no","label"=>__("No","gravity-hotel-rooms-majdi-awad")) ;
		printf("<tr>");
		printf("<th scope=\"row\"><label class=\"GHR-control-label\" for=\"GHR_postmeta_pool_view\">". __("Pool view", "gravity-hotel-rooms-majdi-awad"). "</label></th>");
		printf("<td>");
		printf("<select class=\"GHR GHR-form-control\" id=\"GHR_postmeta_pool_view\" name=\"GHR_postmeta_pool_view\" >") ;
		foreach ($input_options as $input_option)
		{
			$selected="";
			if($input_option["value"]== $current_GHR_postmeta_pool_view){ $selected="selected=\"selected\"";}
			printf("<option value='".$input_option["value"]."' ".$selected.">".$input_option["label"]."</option>") ;
		}
		printf("</select>") ;
		printf("</td>") ;
		printf("</tr>");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_GHR_postmeta_bath= get_post_meta($post->ID, "_GHR_postmeta_bath", true);

		/** Display the form bath, using the current value. **/
		$input_options = array();
		$input_options[] = array("value"=>"yes","label"=>__("Yes","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"no","label"=>__("No","gravity-hotel-rooms-majdi-awad")) ;
		printf("<tr>");
		printf("<th scope=\"row\"><label class=\"GHR-control-label\" for=\"GHR_postmeta_bath\">". __("Bath", "gravity-hotel-rooms-majdi-awad"). "</label></th>");
		printf("<td>");
		printf("<select class=\"GHR GHR-form-control\" id=\"GHR_postmeta_bath\" name=\"GHR_postmeta_bath\" >") ;
		foreach ($input_options as $input_option)
		{
			$selected="";
			if($input_option["value"]== $current_GHR_postmeta_bath){ $selected="selected=\"selected\"";}
			printf("<option value='".$input_option["value"]."' ".$selected.">".$input_option["label"]."</option>") ;
		}
		printf("</select>") ;
		printf("</td>") ;
		printf("</tr>");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_GHR_postmeta_air_conditioning= get_post_meta($post->ID, "_GHR_postmeta_air_conditioning", true);

		/** Display the form air_conditioning, using the current value. **/
		$input_options = array();
		$input_options[] = array("value"=>"yes","label"=>__("Yes","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"no","label"=>__("No","gravity-hotel-rooms-majdi-awad")) ;
		printf("<tr>");
		printf("<th scope=\"row\"><label class=\"GHR-control-label\" for=\"GHR_postmeta_air_conditioning\">". __("Air conditioning", "gravity-hotel-rooms-majdi-awad"). "</label></th>");
		printf("<td>");
		printf("<select class=\"GHR GHR-form-control\" id=\"GHR_postmeta_air_conditioning\" name=\"GHR_postmeta_air_conditioning\" >") ;
		foreach ($input_options as $input_option)
		{
			$selected="";
			if($input_option["value"]== $current_GHR_postmeta_air_conditioning){ $selected="selected=\"selected\"";}
			printf("<option value='".$input_option["value"]."' ".$selected.">".$input_option["label"]."</option>") ;
		}
		printf("</select>") ;
		printf("</td>") ;
		printf("</tr>");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_GHR_postmeta_ensuite_bathroom= get_post_meta($post->ID, "_GHR_postmeta_ensuite_bathroom", true);

		/** Display the form ensuite_bathroom, using the current value. **/
		$input_options = array();
		$input_options[] = array("value"=>"yes","label"=>__("Yes","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"no","label"=>__("No","gravity-hotel-rooms-majdi-awad")) ;
		printf("<tr>");
		printf("<th scope=\"row\"><label class=\"GHR-control-label\" for=\"GHR_postmeta_ensuite_bathroom\">". __("Ensuite bathroom", "gravity-hotel-rooms-majdi-awad"). "</label></th>");
		printf("<td>");
		printf("<select class=\"GHR GHR-form-control\" id=\"GHR_postmeta_ensuite_bathroom\" name=\"GHR_postmeta_ensuite_bathroom\" >") ;
		foreach ($input_options as $input_option)
		{
			$selected="";
			if($input_option["value"]== $current_GHR_postmeta_ensuite_bathroom){ $selected="selected=\"selected\"";}
			printf("<option value='".$input_option["value"]."' ".$selected.">".$input_option["label"]."</option>") ;
		}
		printf("</select>") ;
		printf("</td>") ;
		printf("</tr>");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_GHR_postmeta_free_wifi= get_post_meta($post->ID, "_GHR_postmeta_free_wifi", true);

		/** Display the form free_wifi, using the current value. **/
		$input_options = array();
		$input_options[] = array("value"=>"yes","label"=>__("Yes","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"no","label"=>__("No","gravity-hotel-rooms-majdi-awad")) ;
		printf("<tr>");
		printf("<th scope=\"row\"><label class=\"GHR-control-label\" for=\"GHR_postmeta_free_wifi\">". __("Free WiFi", "gravity-hotel-rooms-majdi-awad"). "</label></th>");
		printf("<td>");
		printf("<select class=\"GHR GHR-form-control\" id=\"GHR_postmeta_free_wifi\" name=\"GHR_postmeta_free_wifi\" >") ;
		foreach ($input_options as $input_option)
		{
			$selected="";
			if($input_option["value"]== $current_GHR_postmeta_free_wifi){ $selected="selected=\"selected\"";}
			printf("<option value='".$input_option["value"]."' ".$selected.">".$input_option["label"]."</option>") ;
		}
		printf("</select>") ;
		printf("</td>") ;
		printf("</tr>");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_GHR_postmeta_flat_screen_tv= get_post_meta($post->ID, "_GHR_postmeta_flat_screen_tv", true);

		/** Display the form flat_screen_tv, using the current value. **/
		$input_options = array();
		$input_options[] = array("value"=>"yes","label"=>__("Yes","gravity-hotel-rooms-majdi-awad")) ;
		$input_options[] = array("value"=>"no","label"=>__("No","gravity-hotel-rooms-majdi-awad")) ;
		printf("<tr>");
		printf("<th scope=\"row\"><label class=\"GHR-control-label\" for=\"GHR_postmeta_flat_screen_tv\">". __("Flat-screen TV", "gravity-hotel-rooms-majdi-awad"). "</label></th>");
		printf("<td>");
		printf("<select class=\"GHR GHR-form-control\" id=\"GHR_postmeta_flat_screen_tv\" name=\"GHR_postmeta_flat_screen_tv\" >") ;
		foreach ($input_options as $input_option)
		{
			$selected="";
			if($input_option["value"]== $current_GHR_postmeta_flat_screen_tv){ $selected="selected=\"selected\"";}
			printf("<option value='".$input_option["value"]."' ".$selected.">".$input_option["label"]."</option>") ;
		}
		printf("</select>") ;
		printf("</td>") ;
		printf("</tr>");
		echo "</table>";
	}
}
