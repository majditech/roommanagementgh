Create a file POT, PO and MO using POEdit or Loco Translate Plugin, 
then rename accordance with textdomain used by the plugin, as follows:

* gravity-hotel-rooms-majdi-awad-de_DE.po
* gravity-hotel-rooms-majdi-awad-id_ID.po
* gravity-hotel-rooms-majdi-awad-es_ES.po
* gravity-hotel-rooms-majdi-awad-en_US.po

* gravity-hotel-rooms-majdi-awad-de_DE.mo
* gravity-hotel-rooms-majdi-awad-id_ID.mo
* gravity-hotel-rooms-majdi-awad-es_ES.mo
* gravity-hotel-rooms-majdi-awad-en_US.mo


Download:
* http://wordpress.org/extend/plugins/loco-translate
* http://poedit.net/download
