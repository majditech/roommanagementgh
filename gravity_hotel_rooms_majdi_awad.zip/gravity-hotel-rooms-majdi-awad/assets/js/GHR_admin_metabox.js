/**
 * @Author :Majdi Awad
 * @Author URL : http://googlit.tech/
 * @License : http://googlit.tech/
 * @License URL: http://googlit.tech/
 *
 * @Package : Gravity Hotel Rooms - Majdi Awad
 * @Version : 1.0
**/


(function($)
{
	
	/**
	 * GHR
	 * name :ghr
	 * postmeta : room_type
	 * label : Room Type
	**/
	
	/**
	 * GHR
	 * name :ghr
	 * postmeta : bed_type
	 * label : Bed Type
	**/
	
	/**
	 * GHR
	 * name :ghr
	 * postmeta : sea_view
	 * label : Sea View
	**/
	
	/**
	 * GHR
	 * name :ghr
	 * postmeta : balcony
	 * label : Balcony
	**/
	
	/**
	 * GHR
	 * name :ghr
	 * postmeta : pool_view
	 * label : Pool view
	**/
	
	/**
	 * GHR
	 * name :ghr
	 * postmeta : bath
	 * label : Bath
	**/
	
	/**
	 * GHR
	 * name :ghr
	 * postmeta : air_conditioning
	 * label : Air conditioning
	**/
	
	/**
	 * GHR
	 * name :ghr
	 * postmeta : ensuite_bathroom
	 * label : Ensuite bathroom
	**/
	
	/**
	 * GHR
	 * name :ghr
	 * postmeta : free_wifi
	 * label : Free WiFi
	**/
	
	/**
	 * GHR
	 * name :ghr
	 * postmeta : flat_screen_tv
	 * label : Flat-screen TV
	**/
})(jQuery);
